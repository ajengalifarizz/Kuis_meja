/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis_ajeng;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import kuis.db.DBHelper;

public class mejaDataModel {
    
    private final  Connection conn;

    public mejaDataModel() throws SQLException {
        this.conn =DBHelper.getConnection();
    }
    
    public void addmeja(meja meja){
    String insertvga = "INSERT INTO tabel_meja ( `tanggal_pembelian`, `merek`, `harga`, `jenis`, `warna`)"
            + "VALUES ('"
            +meja.getTanggal_pembelian()+"','"
            +meja.getMerek()+"','"
            +meja.getHarga()+"','"
            +meja.getJenis()+"','"
            +meja.getWarna()+"')";
    try {
    
    PreparedStatement card = (PreparedStatement) conn.prepareStatement(insertvga);
//    
////    
//    
    card.execute();
    }
    catch(Exception e){
        System.out.println("eror "+e);
    }
    }
    
}
